// app/config/auth.config.js
export default {
    secret: "f57adca865cbf70ccd5a0cdfce9bd590",
};