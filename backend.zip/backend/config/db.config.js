// app/config/db.config.js
export default {
    HOST: "mx92.hostgator.mx",
    USER: "cesarga1_admin_app",
    PASSWORD: "x^Pl{R(YqkgZoY~I",
    DB: "cesarga1_database_app",
    PORT: 3306,
    dialect:"mysql",
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000,
    },
};