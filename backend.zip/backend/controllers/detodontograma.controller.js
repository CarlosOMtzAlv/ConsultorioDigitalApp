// app/controllers/detOdontograma.controller.js
import db from "../models/index.js";

const detOdontogramaModel = db.detodontogramas;

export const getAlldetOdontogramas = async (req, res) => {
    try {
        const detOdontograma = await detOdontogramaModel.findAll();
        res.status(200).json(detOdontograma);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getdetOdontograma = async (req, res) => {
    try {
        const detOdontograma = await detOdontogramaModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(detOdontograma);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertdetOdontograma = async (req, res) => {
    try {
        await detOdontogramaModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updatedetOdontograma = async (req, res) => {
    try {
        await detOdontogramaModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deletedetOdontograma = async (req, res) => {
    try {
        await detOdontogramaModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};