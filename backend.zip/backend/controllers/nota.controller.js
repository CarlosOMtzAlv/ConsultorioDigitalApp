// app/controllers/expediente.controller.js
import db from "../models/index.js";
import { Sequelize } from "sequelize";

const NotaModel = db.notas;

//Mostrar todos los registros
export const getAllNotas = async (req, res) => {
    try {
        const Notas = await NotaModel.findAll()
        res.json(Notas)
    } catch (error) {
        res.json( {message: error.message} )
    }
}
//Mostrar un registro
export const getNota = async (req, res) => {
        try {
            const Nota = await NotaModel.findAll({
                where:{ id:req.params.id }
            })
            res.json(Nota[0])
        } catch (error) {
            res.json( {message: error.message} )
        }
}
//Mostrar los registros por Paciente
export const getNotaExp = async (req, res) => {
    try {
        const Nota = await NotaModel.findAll({
            where:{ idExpediente:req.params.id }
        })
        res.json(Nota)
    } catch (error) {
        res.json( {message: error.message} )
    }
}
//Crear un registro
export const createNota = async (req, res) => {
    try {
       await NotaModel.create(req.body)
       .then(result => res.json(
           {
               "id": result.id,
               "message": "¡Registro creado correctamente!"
           }));
    } catch (error) {
        res.json( {message: error.message} )
    }
}
//Actualizar un registro
export const updateNota = async (req, res) => {
    try {
        await NotaModel.update(req.body, {
            where: { id: req.params.id}
        })
        res.json({
            "message":"¡Registro actualizado correctamente!"
        })
    } catch (error) {
        res.json( {message: error.message} )
    }
}
//Eliminar un registro
export const deleteNota = async (req, res) => {
    try {
        await NotaModel.destroy({ 
            where: { id : req.params.id }
        })
        res.json({
            "message":"¡Registro eliminado correctamente!"
        })
    } catch (error) {
        res.json( {message: error.message} )
    }
}

//Obtener ultima limpieza por Expediente
export const getUltimaLimpieza = async (req, res) => {
    try {
        const Nota = await NotaModel.findAll({
            where:{ chkLimpieza:req.params.id },
            attributes: ['idExpediente',[Sequelize.fn('max', Sequelize.col('fecha')),'ultimaLimpieza']],
            group: ['idExpediente']
        })
        res.json(Nota)
    } catch (error) {
        res.json( {message: error.message} )
    }
}

//Obtener ultima visita con base a la ultima nota de evolucion registrada
export const getUltimaVisita = async (req, res) => {
    try {
        const Nota = await NotaModel.findAll({
            attributes: ['idExpediente',[Sequelize.fn('max', Sequelize.col('fecha')),'ultimaVisita']],
            group: ['idExpediente'],
            order: [Sequelize.literal('max(fecha) ASC')],
            include: [
                {
                    model: ExpedienteModel,
                    required: true,
                    attributes: ['nombre','apellidoPaterno','apellidoMaterno','telefono']
                }
            ]
        })
        res.json(Nota)
    } catch (error) {
        res.json( {message: error.message} )
    }
}
;
