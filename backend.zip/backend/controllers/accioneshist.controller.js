// app/controllers/AccionesHist.controller.js
import db from "../models/index.js";

const AccionesHistModel = db.accioneshist;

export const getAllAccionesHist = async (req, res) => {
    try {
        const AccionesHist = await AccionesHistModel.findAll();
        res.status(200).json(AccionesHist);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getAccionesHist = async (req, res) => {
    try {
        const AccionesHist = await AccionesHistModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(AccionesHist);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertAccionesHist = async (req, res) => {
    try {
        await AccionesHistModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateAccionesHist = async (req, res) => {
    try {
        await AccionesHistModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteAccionesHist = async (req, res) => {
    try {
        await AccionesHistModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};