// app/controllers/tipofolio.controller.js
import db from "../models/index.js";

const tipofolioModel = db.tipofolio;

export const getAllTipoFolio = async (req, res) => {
    try {
        const tipofolio = await tipofolioModel.findAll();
        res.status(200).json(tipofolio);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getTipoFolio = async (req, res) => {
    try {
        const tipofolio = await tipofolioModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(tipofolio);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertTipoFolio = async (req, res) => {
    try {
        await tipofolioModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateTipoFolio = async (req, res) => {
    try {
        await tipofolioModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteTipoFolio = async (req, res) => {
    try {
        await tipofolioModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};