// app/controllers/cobranza.controller.js
import db from "../models/index.js";

const cobranzaModel = db.cobranzas;

export const getAllCobranzas = async (req, res) => {
    try {
        const cobranza = await cobranzaModel.findAll();
        res.status(200).json(cobranza);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getCobranza = async (req, res) => {
    try {
        const cobranza = await cobranzaModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(cobranza);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertCobranza = async (req, res) => {
    try {
        await cobranzaModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateCobranza = async (req, res) => {
    try {
        await cobranzaModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteCobranza = async (req, res) => {
    try {
        await cobranzaModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};