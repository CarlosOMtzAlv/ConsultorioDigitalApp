// app/controllers/tratamiento.controller.js
import db from "../models/index.js";

const tratamientoModel = db.tratamientos;

export const getAllTratamientos = async (req, res) => {
    try {
        const tratamientos = await tratamientoModel.findAll();
        res.status(200).json(tratamientos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getTratamiento = async (req, res) => {
    try {
        const tratamientos = await tratamientoModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(tratamientos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertTratamiento = async (req, res) => {
    try {
        await tratamientoModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateTratamiento = async (req, res) => {
    try {
        await tratamientoModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteTratamiento = async (req, res) => {
    try {
        await tratamientoModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};