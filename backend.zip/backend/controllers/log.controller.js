// app/controllers/log.controller.js
import db from "../models/index.js";

const logModel = db.logs;

export const getAllLogs = async (req, res) => {
    try {
        const logs = await logModel.findAll();
        res.status(200).json(logs);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getLog = async (req, res) => {
    try {
        const logs = await logModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(logs);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertLog = async (req, res) => {
    try {
        await logModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateLog = async (req, res) => {
    try {
        await logModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteLog = async (req, res) => {
    try {
        await logModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};