// app/controllers/dettratamiento.controller.js
import db from "../models/index.js";

const dettratamientoModel = db.dettratamientos;

export const getAlldetTratamientos = async (req, res) => {
    try {
        const dettratamiento = await dettratamientoModel.findAll();
        res.status(200).json(dettratamiento);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getdetTratamiento = async (req, res) => {
    try {
        const dettratamiento = await dettratamientoModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(dettratamiento);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertdetTratamiento = async (req, res) => {
    try {
        await dettratamientoModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updatedetTratamiento = async (req, res) => {
    try {
        await dettratamientoModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deletedetTratamiento = async (req, res) => {
    try {
        await dettratamientoModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};