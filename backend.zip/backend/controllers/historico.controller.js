// app/controllers/Historico.controller.js
import db from "../models/index.js";

const HistoricoModel = db.historicos;
const objetoModel = db.objetos;

export const getAllHistoricos = async (req, res) => {
    try {
        const Historicos = await HistoricoModel.findAll();
        res.status(200).json(Historicos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getHistorico = async (req, res) => {
    try {
        const Historicos = await HistoricoModel.findAll({
            where: { id: req.params.id },
            include: {
                model: objetoModel,
                as: "objetos"
            }
        });
        res.status(200).json(Historicos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertHistorico = async (req, res) => {
    try {
        await HistoricoModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateHistorico = async (req, res) => {
    try {
        await HistoricoModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteHistorico = async (req, res) => {
    try {
        await HistoricoModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};