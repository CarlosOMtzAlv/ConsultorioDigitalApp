// app/controllers/estatus.controller.js
import db from "../models/index.js";

const estatusModel = db.estatus;

export const getAllEstatus = async (req, res) => {
    try {
        const estatuss = await estatusModel.findAll();
        res.status(200).json(estatuss);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getEstatus = async (req, res) => {
    try {
        const estatuss = await estatusModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(estatuss);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertEstatus = async (req, res) => {
    try {
        await estatusModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateEstatus = async (req, res) => {
    try {
        await estatusModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteEstatus = async (req, res) => {
    try {
        await estatusModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};