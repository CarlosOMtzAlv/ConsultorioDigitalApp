// app/controllers/FormaPago.controller.js
import db from "../models/index.js";

const FormaPagoModel = db.formapagos;

export const getAllFormaPagos = async (req, res) => {
    try {
        const FormaPagos = await FormaPagoModel.findAll();
        res.status(200).json(FormaPagos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getFormaPago = async (req, res) => {
    try {
        const FormaPagos = await FormaPagoModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(FormaPagos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertFormaPago = async (req, res) => {
    try {
        await FormaPagoModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateFormaPago = async (req, res) => {
    try {
        await FormaPagoModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteFormaPago = async (req, res) => {
    try {
        await FormaPagoModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};