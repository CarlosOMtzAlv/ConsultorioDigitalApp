// app/controllers/menuoptions.controller.js
import db from "../models/index.js";

const menuOptionsModel = db.menuoptions;
const menuSectionsModel = db.menusections;

export const getAllMenuOptions = async (req, res) => {
    try {
        const menuOptions = await menuOptionsModel.findAll({
            include: [{
                model: menuSectionsModel,
                as: "menu_sections"
            }],
            order: [["orden", "ASC"]]
        });
        res.status(200).json(menuOptions);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getMenuOption = async (req, res) => {
    try {
        const menuOptions = await menuOptionsModel.findAll({
            where: { id: req.params.id },
            include: [{
                model: menuSectionsModel,
                as: "menu_sections"
            }],
            order: [["orden", "ASC"]]
        });
        res.status(200).json(menuOptions);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
// GET MENU OPTIONS BY SECTION
export const getMenuOptionsBySection = async (req, res) => {
    try {
        const menuOptions = await menuOptionsModel.findAll({
            where: {
                idSection: req.params.id
            },
            order: [["orden", "ASC"]]
        });

        return res.status(200).json(menuOptions);

    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
};
export const insertMenuOption = async (req, res) => {
    try {
        await menuOptionsModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateMenuOption = async (req, res) => {
    try {
        await menuOptionsModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteMenuOption = async (req, res) => {
    try {
        await menuOptionsModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};