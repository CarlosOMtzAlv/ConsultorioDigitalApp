// app/controllers/llamadaHist.controller.js
import db from "../models/index.js";

const llamadaHistModel = db.llamadahist;

export const getAllLlamadaHist = async (req, res) => {
    try {
        const llamadaHists = await llamadaHistModel.findAll();
        res.status(200).json(llamadaHists);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getLlamadaHist = async (req, res) => {
    try {
        const llamadaHists = await llamadaHistModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(llamadaHists);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertLlamadaHist = async (req, res) => {
    try {
        await llamadaHistModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateLlamadaHist = async (req, res) => {
    try {
        await llamadaHistModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteLlamadaHist = async (req, res) => {
    try {
        await llamadaHistModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};