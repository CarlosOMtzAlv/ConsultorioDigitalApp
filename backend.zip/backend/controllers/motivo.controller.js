// app/controllers/motivo.controller.js
import db from "../models/index.js";

const motivoModel = db.motivos;

export const getAllmotivos = async (req, res) => {
    try {
        const motivos = await motivoModel.findAll();
        res.status(200).json(motivos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getmotivo = async (req, res) => {
    try {
        const motivos = await motivoModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(motivos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertmotivo = async (req, res) => {
    try {
        await motivoModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updatemotivo = async (req, res) => {
    try {
        await motivoModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deletemotivo = async (req, res) => {
    try {
        await motivoModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};