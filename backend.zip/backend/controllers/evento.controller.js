// app/controllers/evento.controller.js
import db from "../models/index.js";

const eventoModel = db.eventos;

export const getAllEventos = async (req, res) => {
    try {
        const eventos = await eventoModel.findAll();
        res.status(200).json(eventos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getEvento = async (req, res) => {
    try {
        const eventos = await eventoModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(eventos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertEvento = async (req, res) => {
    try {
        await eventoModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateEvento = async (req, res) => {
    try {
        await eventoModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteEvento = async (req, res) => {
    try {
        await eventoModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};