// app/controllers/menusections.controller.js
import db from "../models/index.js";

const menuSectionsModel = db.menusections;

export const getAllMenuSections = async (req, res) => {
    try {
        const menusections = await menuSectionsModel.findAll();
        res.status(200).json(menusections);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getMenuSection = async (req, res) => {
    try {
        const menusections = await menuSectionsModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(menusections);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertMenuSection = async (req, res) => {
    try {
        await menuSectionsModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateMenuSection = async (req, res) => {
    try {
        await menuSectionsModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteMenuSection = async (req, res) => {
    try {
        await menuSectionsModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};