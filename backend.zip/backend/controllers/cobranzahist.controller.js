// app/controllers/cobranzaHist.controller.js
import db from "../models/index.js";

const cobranzaHistModel = db.cobranzahist;

export const getAllCobranzaHist = async (req, res) => {
    try {
        const cobranzaHist = await cobranzaHistModel.findAll();
        res.status(200).json(cobranzaHist);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getCobranzaHist = async (req, res) => {
    try {
        const cobranzaHist = await cobranzaHistModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(cobranzaHist);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertCobranzaHist = async (req, res) => {
    try {
        await cobranzaHistModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateCobranzaHist = async (req, res) => {
    try {
        await cobranzaHistModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteCobranzaHist = async (req, res) => {
    try {
        await cobranzaHistModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};