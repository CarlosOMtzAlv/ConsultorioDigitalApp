// app/controllers/menuoptions.controller.js
import db from "../models/index.js";

const menuOptionsRoleModel = db.menuoptionsrole;
const roleModel = db.role;
const menuOptionsModel = db.menuoptions;

export const getAllMenuOptionsRole = async (req, res) => {
    try {
        const menuOptionsRole = await menuOptionsRoleModel.findAll({
            include: [{
                model: roleModel,
                as: "roles"
            },{
                model: menuOptionsModel,
                as: "menu_options"
        }]
        });
        res.status(200).json(menuOptionsRole);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const insertMenuOptionRole = async (req, res) => {
    try {
        await menuOptionsRoleModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateMenuOptionRole = async (req, res) => {
    try {
        await menuOptionsRoleModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteMenuOptionRole = async (req, res) => {
    try {
        await menuOptionsRoleModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};