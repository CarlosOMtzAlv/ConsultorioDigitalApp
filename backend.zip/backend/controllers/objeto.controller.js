// app/controllers/objeto.controller.js
import db from "../models/index.js";

const ObjetoModel = db.objetos;

export const getAllObjetos = async (req, res) => {
    try {
        const Objetos = await ObjetoModel.findAll();
        res.status(200).json(Objetos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getObjeto = async (req, res) => {
    try {
        const Objetos = await ObjetoModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(Objetos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertObjeto = async (req, res) => {
    try {
        await ObjetoModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateObjeto = async (req, res) => {
    try {
        await ObjetoModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteObjeto = async (req, res) => {
    try {
        await ObjetoModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};