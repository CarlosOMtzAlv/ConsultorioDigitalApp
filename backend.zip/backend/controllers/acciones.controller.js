// app/controllers/Acciones.controller.js
import db from "../models/index.js";

const AccionesModel = db.acciones;

export const getAllAcciones = async (req, res) => {
    try {
        const Acciones = await AccionesModel.findAll();
        res.status(200).json(Acciones);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getAcciones = async (req, res) => {
    try {
        const Acciones = await AccionesModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(Acciones);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertAcciones = async (req, res) => {
    try {
        await AccionesModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateAcciones = async (req, res) => {
    try {
        await AccionesModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteAcciones = async (req, res) => {
    try {
        await AccionesModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};