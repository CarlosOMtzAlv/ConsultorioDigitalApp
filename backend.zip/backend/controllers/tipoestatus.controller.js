// app/controllers/tipoestatus.controller.js
import db from "../models/index.js";

const tipoestatusModel = db.tipoestatus;

export const getAllTipoEstatus = async (req, res) => {
    try {
        const tipoestatus = await tipoestatusModel.findAll();
        res.status(200).json(tipoestatus);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getTipoEstatus = async (req, res) => {
    try {
        const tipoestatus = await tipoestatusModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(tipoestatus);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertTipoEstatus = async (req, res) => {
    try {
        await tipoestatusModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateTipoEstatus = async (req, res) => {
    try {
        await tipoestatusModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteTipoEstatus = async (req, res) => {
    try {
        await tipoestatusModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};