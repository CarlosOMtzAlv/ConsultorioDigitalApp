// app/controllers/recetas.controller.js
import db from "../models/index.js";

const recetasModel = db.recetas;

export const getAllRecetas = async (req, res) => {
    try {
        const recetass = await recetasModel.findAll();
        res.status(200).json(recetass);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getRecetas = async (req, res) => {
    try {
        const recetass = await recetasModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(recetass);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertRecetas = async (req, res) => {
    try {
        await recetasModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateRecetas = async (req, res) => {
    try {
        await recetasModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteRecetas = async (req, res) => {
    try {
        await recetasModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};