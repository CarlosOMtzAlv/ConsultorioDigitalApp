// app/controllers/municipio.controller.js
import db from "../models/index.js";

const municipioModel = db.municipios;
const estadoModel = db.estados;

export const getAllMunicipio = async (req, res) => {
    try {
        const municipios = await municipioModel.findAll();
        res.status(200).json(municipios);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const getMunicipioEstado = async (req, res) => {
    try {
        const municipios = await municipioModel.findAll({
            include: [
            {
            model: estadoModel,
            as: "estados",
            attributes: ["id", "nombre"], // solo id y nombre
            through: { attributes: [] }, // 👈 no mostrar la tabla pivote
            },
        ],
        });
        res.status(200).json(municipios);
    }catch (error) {
        res.status(500).json({ message: error.message });
    }
};

export const getMunicipio = async (req, res) => {
    try {
        const municipios = await municipioModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(municipios);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};