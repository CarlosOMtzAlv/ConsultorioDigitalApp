// app/controllers/expediente.controller.js
import db from "../models/index.js";

const expedienteModel = db.expedientes;

export const getAllExpedientes = async (req, res) => {
    try {
        const expedientes = await expedienteModel.findAll();
        res.status(200).json(expedientes);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getExpediente = async (req, res) => {
    try {
        const expedientes = await expedienteModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(expedientes);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertExpediente = async (req, res) => {
    try {
        await expedienteModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateExpediente = async (req, res) => {
    try {
        await expedienteModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteExpediente = async (req, res) => {
    try {
        await expedienteModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};