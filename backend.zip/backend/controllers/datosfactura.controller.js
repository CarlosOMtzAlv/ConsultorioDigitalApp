// app/controllers/datosFactura.controller.js
import db from "../models/index.js";

const datosFacturaModel = db.datosfacturas;

export const getAllDatosFacturas = async (req, res) => {
    try {
        const datosFacturas = await datosFacturaModel.findAll();
        res.status(200).json(datosFacturas);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getDatosFactura = async (req, res) => {
    try {
        const datosFacturas = await datosFacturaModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(datosFacturas);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertDatosFactura = async (req, res) => {
    try {
        await datosFacturaModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateDatosFactura = async (req, res) => {
    try {
        await datosFacturaModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteDatosFactura = async (req, res) => {
    try {
        await datosFacturaModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};