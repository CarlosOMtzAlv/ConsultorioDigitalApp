// app/controllers/expediente.controller.js
import db from "../models/index.js";
import { Sequelize } from "sequelize";

const presupuestoModel = db.presupuestos;

//Mostrar todos los registros
export const getAllPresupuestos = async (req, res) => {
    try {
        const presupuestos = await presupuestoModel.findAll()
        res.json(presupuestos)
    } catch (error) {
        res.json( {message: error.message} )
    }
}
//Mostrar un registro
export const getPresupuesto = async (req, res) => {
        try {
            const presupuesto = await presupuestoModel.findAll({
                where:{ id:req.params.id }
            })
            res.json(presupuesto[0])
        } catch (error) {
            res.json( {message: error.message} )
        }
}
//Mostrar los registros por Paciente
export const getPresupuestoExp = async (req, res) => {
    try {
        const presupuesto = await presupuestoModel.findAll({
            where:{ idExpediente:req.params.id }
        })
        res.json(presupuesto)
    } catch (error) {
        res.json( {message: error.message} )
    }
}
//Crear un registro
export const createPresupuesto = async (req, res) => {
    try {
       await presupuestoModel.create(req.body)
       .then(result => res.json(
           {
               "id": result.id,
               "message": "¡Registro creado correctamente!"
           }));
    } catch (error) {
        res.json( {message: error.message} )
    }
}
//Actualizar un registro
export const updatePresupuesto = async (req, res) => {
    try {
        await presupuestoModel.update(req.body, {
            where: { id: req.params.id}
        })
        res.json({
            "message":"¡Registro actualizado correctamente!"
        })
    } catch (error) {
        res.json( {message: error.message} )
    }
}
//Eliminar un registro
export const deletePresupuesto = async (req, res) => {
    try {
        await presupuestoModel.destroy({ 
            where: { id : req.params.id }
        })
        res.json({
            "message":"¡Registro eliminado correctamente!"
        })
    } catch (error) {
        res.json( {message: error.message} )
    }
}

//Obtener ultima limpieza por Expediente
export const getUltimaLimpieza = async (req, res) => {
    try {
        const presupuesto = await presupuestoModel.findAll({
            where:{ chkLimpieza:req.params.id },
            attributes: ['idExpediente',[Sequelize.fn('max', Sequelize.col('fecha')),'ultimaLimpieza']],
            group: ['idExpediente']
        })
        res.json(presupuesto)
    } catch (error) {
        res.json( {message: error.message} )
    }
}

//Obtener ultima visita con base a la ultima presupuesto de evolucion registrada
export const getUltimaVisita = async (req, res) => {
    try {
        const presupuesto = await presupuestoModel.findAll({
            attributes: ['idExpediente',[Sequelize.fn('max', Sequelize.col('fecha')),'ultimaVisita']],
            group: ['idExpediente'],
            order: [Sequelize.literal('max(fecha) ASC')],
            include: [
                {
                    model: ExpedienteModel,
                    required: true,
                    attributes: ['nombre','apellidoPaterno','apellidoMaterno','telefono']
                }
            ]
        })
        res.json(presupuesto)
    } catch (error) {
        res.json( {message: error.message} )
    }
}
;
