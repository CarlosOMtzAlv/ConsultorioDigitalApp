// app/controllers/odontograma.controller.js
import db from "../models/index.js";

const odontogramaModel = db.odontogramas;

export const getAllOdontogramas = async (req, res) => {
    try {
        const odontogramas = await odontogramaModel.findAll();
        res.status(200).json(odontogramas);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getOdontograma = async (req, res) => {
    try {
        const odontogramas = await odontogramaModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(odontogramas);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertOdontograma = async (req, res) => {
    try {
        await odontogramaModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateOdontograma = async (req, res) => {
    try {
        await odontogramaModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteOdontograma = async (req, res) => {
    try {
        await odontogramaModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};