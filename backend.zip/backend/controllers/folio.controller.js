// app/controllers/folio.controller.js
import db from "../models/index.js";

const folioModel = db.folios;

export const getAllFolios = async (req, res) => {
    try {
        const folios = await folioModel.findAll();
        res.status(200).json(folios);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getFolio = async (req, res) => {
    try {
        const folios = await folioModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(folios);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertFolio = async (req, res) => {
    try {
        await folioModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateFolio = async (req, res) => {
    try {
        await folioModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteFolio = async (req, res) => {
    try {
        await folioModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};