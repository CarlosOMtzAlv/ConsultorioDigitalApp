// app/controllers/orden.controller.js
import db from "../models/index.js";

const ordenModel = db.orden;

export const getAllOrden = async (req, res) => {
    try {
        const ordens = await ordenModel.findAll();
        res.status(200).json(ordens);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getOrden = async (req, res) => {
    try {
        const ordens = await ordenModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(ordens);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertOrden = async (req, res) => {
    try {
        await ordenModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateOrden = async (req, res) => {
    try {
        await ordenModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteOrden = async (req, res) => {
    try {
        await ordenModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};