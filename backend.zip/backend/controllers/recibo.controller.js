// app/controllers/recibos.controller.js
import db from "../models/index.js";

const recibosModel = db.recibos;

export const getAllRecibos = async (req, res) => {
    try {
        const reciboss = await recibosModel.findAll();
        res.status(200).json(reciboss);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getRecibos = async (req, res) => {
    try {
        const reciboss = await recibosModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(reciboss);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertRecibos = async (req, res) => {
    try {
        await recibosModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateRecibos = async (req, res) => {
    try {
        await recibosModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteRecibos = async (req, res) => {
    try {
        await recibosModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};