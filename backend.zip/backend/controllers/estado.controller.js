// app/controllers/estado.controller.js
import db from "../models/index.js";

const estadoModel = db.estados;

export const getAllEstados = async (req, res) => {
    try {
        const estados = await estadoModel.findAll();
        res.status(200).json(estados);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getEstado = async (req, res) => {
    try {
        const estados = await estadoModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(estados);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertEstado = async (req, res) => {
    try {
        await estadoModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateEstado = async (req, res) => {
    try {
        await estadoModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteEstado = async (req, res) => {
    try {
        await estadoModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};