// app/controllers/limpiezaHist.controller.js
import db from "../models/index.js";

const limpiezaHistModel = db.limpiezahist;

export const getAllLimpiezaHist = async (req, res) => {
    try {
        const limpiezaHists = await limpiezaHistModel.findAll();
        res.status(200).json(limpiezaHists);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getLimpiezaHist = async (req, res) => {
    try {
        const limpiezaHists = await limpiezaHistModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(limpiezaHists);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertLimpiezaHist = async (req, res) => {
    try {
        await limpiezaHistModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateLimpiezaHist = async (req, res) => {
    try {
        await limpiezaHistModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteLimpiezaHist = async (req, res) => {
    try {
        await limpiezaHistModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};