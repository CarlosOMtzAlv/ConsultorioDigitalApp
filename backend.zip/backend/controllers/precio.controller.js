// app/controllers/precio.controller.js
import db from "../models/index.js";

const precioModel = db.precios;

export const getAllPrecio = async (req, res) => {
    try {
        const precios = await precioModel.findAll();
        res.status(200).json(precios);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getPrecio = async (req, res) => {
    try {
        const precios = await precioModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(precios);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertPrecio = async (req, res) => {
    try {
        await precioModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updatePrecio = async (req, res) => {
    try {
        await precioModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deletePrecio = async (req, res) => {
    try {
        await precioModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};