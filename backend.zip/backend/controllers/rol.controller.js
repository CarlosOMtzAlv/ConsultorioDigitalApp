// app/controllers/rol.controller.js
import db from "../models/index.js";

const roleModel = db.role;

export const getAllroles = async (req, res) => {
    try {
        const roles = await roleModel.findAll();
        res.status(200).json(roles);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const getRol = async (req, res) => {
    try {
        const roles = await roleModel.findAll({
            where: { id: req.params.id }
        });
        res.status(200).json(roles);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const insertRol = async (req, res) => {
    try {
        await roleModel.create(req.body);
        res.status(200).json({"message": "¡Registro creado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const updateRol = async (req, res) => {
    try {
        await roleModel.update(req.body, {
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro actualizado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
export const deleteRol = async (req, res) => {
    try {
        await roleModel.destroy({
            where: { id: req.params.id }
        })
        res.status(200).json({"message": "¡Registro eliminado correctamente!"});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};