// server.js
import express from "express";
import cors from "cors";
import db from "./models/index.js";
import accionesRoutes from "./routes/acciones.routes.js";
import accioneshistRoutes from "./routes/accioneshit.routes.js";
import authRoutes from "./routes/auth.routes.js";
import cobranzaRoutes from "./routes/cobranza.routes.js";
import cobranzahistRoutes from "./routes/cobranzahist.routes.js";
import datosfacturaRoutes from "./routes/datosfactura.routes.js";
import detodontogramaRoutes from "./routes/detodontograma.routes.js";
import dettratamientoRoutes from "./routes/dettratamiento.routes.js";
import folioRoutes from "./routes/folio.routes.js";
import formapagoRoutes from "./routes/formapago.routes.js";
import historicoRoutes from "./routes/historico.routes.js";
import estadoRoutes from "./routes/estado.routes.js";
import estatusRoute from "./routes/estatus.routes.js";
import eventoRoutes from "./routes/evento.routes.js";
import expedienteRoutes from "./routes/expediente.route.js";
import limpiezahistRoutes from "./routes/limpiezahist.routes.js";
import llamadahistRoutes from "./routes/llamadahist.routes.js";
import logRoutes from "./routes/log.routes.js";
import menusectionRoutes from "./routes/menusection.routes.js";
import menuoptionRoutes from "./routes/menuoptions.routes.js";
import menuoptionroleRoutes from "./routes/menuoptionsrole.routes.js";
import motivoRoutes from "./routes/motivo.routes.js";
import municipioRoutes from "./routes/municipio.routes.js";
import notaRoutes from "./routes/nota.routes.js";
import objetoRoutes from "./routes/objeto.routes.js";
import odontogramaRoutes from "./routes/odontograma.routes.js";
import ordenRoutes from "./routes/orden.routes.js";
import precioRoutes from "./routes/precio.routes.js";
import presupuestoRoutes from "./routes/presupuesto.routes.js";
import recetaRoutes from "./routes/receta.routes.js";
import reciboRoutes from "./routes/recibo.routes.js";
import rolRoutes from "./routes/rol.routes.js";
import tipoestatusRoutes from "./routes/tipoestatus.routes.js";
import tipofolioRoutes from "./routes/tipofolio.routes.js";
import tratamientoRoutes from "./routes/tratamiento.routes.js";
import userRoutes from "./routes/user.routes.js";
 
const app = express();
 
const corsOptions = {
    origin: "http://localhost:8081",
};
 
app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
 
// Simple test route
app.get("/", (req, res) => {
    res.json({ message: "Welcome to the Node.js JWT Authentication API." });
});
 
// Routes
app.use("/api/acciones", accionesRoutes);
app.use("/api/accioneshist", accioneshistRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/cobranza", cobranzaRoutes);
app.use("/api/cobranzahist", cobranzahistRoutes);
app.use("/api/datosfactura", datosfacturaRoutes);
app.use("/api/detodontograma", detodontogramaRoutes);
app.use("/api/dettratamiento", dettratamientoRoutes);
app.use("/api/folio", folioRoutes);
app.use("/api/formapago", formapagoRoutes);
app.use("/api/historico", historicoRoutes);
app.use("/api/estado", estadoRoutes);
app.use("/api/estatus", estatusRoute);
app.use("/api/evento", eventoRoutes);
app.use("/api/expediente", expedienteRoutes);
app.use("/api/limpiezahist", limpiezahistRoutes);
app.use("/api/llamadahist", llamadahistRoutes);
app.use("/api/log", logRoutes);
app.use("/api/menusection", menusectionRoutes);
app.use("/api/menuoption", menuoptionRoutes);
app.use("/api/menuoptionrole", menuoptionroleRoutes);
app.use("/api/motivo", motivoRoutes);
app.use("/api/municipio", municipioRoutes);
app.use("/api/nota", notaRoutes);
app.use("/api/objeto", objetoRoutes);
app.use("/api/odontograma", odontogramaRoutes);
app.use("/api/orden", ordenRoutes);
app.use("/api/precio", precioRoutes);
app.use("/api/presupuesto", presupuestoRoutes);
app.use("/api/receta", recetaRoutes);
app.use("/api/recibo", reciboRoutes);
app.use("/api/rol", rolRoutes);
app.use("/api/test", userRoutes);
app.use("/api/tipoestatus", tipoestatusRoutes);
app.use("/api/tipofolio", tipofolioRoutes);
app.use("/api/tratamiento", tratamientoRoutes);
 
// Set port and listen for requests
const PORT = process.env.PORT || 8080;
 
// db.sequelize.sync({ force: false }).then(() => {
//     console.log("Database synchronized");
//     app.listen(PORT, () => {
//         console.log(`Server is running on port ${PORT}.`);
//     });
// });
db.sequelize.authenticate()
    .then(() => {
        console.log("Database connection established successfully.");

        app.listen(PORT, () => {
            console.log(`Server is running on port ${PORT}.`);
        });
    })
    .catch(error => {
        console.error("Database connection error:", error);
    });