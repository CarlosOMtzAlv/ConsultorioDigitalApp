// app/routes/estado.routes.js
import express from "express";
import {
    getAllExpedientes,
    getExpediente,
    insertExpediente,
    updateExpediente,
    deleteExpediente
} from "../controllers/expediente.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllExpedientes);
 
router.get("/:id", [verifyToken], getExpediente);
 
router.post("/create", [verifyToken], insertExpediente);

router.post("/update/:id", [verifyToken], updateExpediente);
 
router.post("/delete/:id", [verifyToken], deleteExpediente);
 
export default router;