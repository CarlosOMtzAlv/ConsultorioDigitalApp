// app/routes/Objeto.routes.js
import express from "express";
import {
    getAllObjetos,
    getObjeto,
    insertObjeto,
    updateObjeto,
    deleteObjeto
} from "../controllers/Objeto.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllObjetos);
 
router.get("/:id", [verifyToken], getObjeto);
 
router.post("/", [verifyToken], insertObjeto);

router.put("/:id", [verifyToken], updateObjeto);
 
router.delete("/:id", [verifyToken], deleteObjeto);
 
export default router;