// app/routes/Tratamientos.routes.js
import express from "express";
import {
    getAllTratamientos,
    getTratamiento,
    insertTratamiento,
    updateTratamiento,
    deleteTratamiento
} from "../controllers/tratamiento.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllTratamientos);
 
router.get("/:id", [verifyToken], getTratamiento);
 
router.post("/", [verifyToken], insertTratamiento);

router.put("/:id", [verifyToken], updateTratamiento);
 
router.delete("/:id", [verifyToken], deleteTratamiento);
 
export default router;