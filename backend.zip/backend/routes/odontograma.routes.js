// app/routes/Odontogramas.routes.js
import express from "express";
import {
    getAllOdontogramas,
    getOdontograma,
    insertOdontograma,
    updateOdontograma,
    deleteOdontograma
} from "../controllers/odontograma.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllOdontogramas);
 
router.get("/:id", [verifyToken], getOdontograma);
 
router.post("/", [verifyToken], insertOdontograma);

router.put("/:id", [verifyToken], updateOdontograma);
 
router.delete("/:id", [verifyToken], deleteOdontograma);
 
export default router;