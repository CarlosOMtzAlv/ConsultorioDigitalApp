// app/routes/AccionesHist.routes.js
import express from "express";
import {
    getAllAccionesHist,
    getAccionesHist,
    insertAccionesHist,
    updateAccionesHist,
    deleteAccionesHist
} from "../controllers/accioneshist.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllAccionesHist);
 
router.get("/:id", [verifyToken], getAccionesHist);
 
router.post("/", [verifyToken], insertAccionesHist);

router.put("/:id", [verifyToken], updateAccionesHist);
 
router.delete("/:id", [verifyToken], deleteAccionesHist);
 
export default router;