// app/routes/estatus.routes.js
import express from "express";
import {
    getAllEstatus,
    getEstatus,
    insertEstatus,
    updateEstatus,
    deleteEstatus
} from "../controllers/estatus.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllEstatus);
 
router.get("/:id", [verifyToken], getEstatus);
 
router.post("/", [verifyToken], insertEstatus);

router.put("/:id", [verifyToken], updateEstatus);
 
router.delete("/:id", [verifyToken], deleteEstatus);
 
export default router;