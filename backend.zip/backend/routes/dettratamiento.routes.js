// app/routes/estado.routes.js
import express from "express";
import {
    getAlldetTratamientos,
    getdetTratamiento,
    insertdetTratamiento,
    updatedetTratamiento,
    deletedetTratamiento
} from "../controllers/dettratamiento.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAlldetTratamientos);
 
router.get("/:id", [verifyToken], getdetTratamiento);
 
router.post("/", [verifyToken], insertdetTratamiento);

router.put("/:id", [verifyToken], updatedetTratamiento);
 
router.delete("/:id", [verifyToken], deletedetTratamiento);
 
export default router;