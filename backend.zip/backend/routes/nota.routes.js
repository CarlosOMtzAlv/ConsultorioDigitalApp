// app/routes/estado.routes.js
import express from "express";
import {
    getAllNotas,
    getNota,
    getNotaExp,
    createNota,
    updateNota,
    deleteNota,
    getUltimaLimpieza,
    getUltimaVisita
} from "../controllers/nota.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllNotas);
 
router.get("/:id", [verifyToken], getNota);

router.get("/expediente/:id", [verifyToken], getNotaExp);
 
router.post("/", [verifyToken], createNota);

router.put("/:id", [verifyToken], updateNota);
 
router.delete("/:id", [verifyToken], deleteNota);

router.get("/limpieza/:id", [verifyToken], getUltimaLimpieza);

router.get("/visita", [verifyToken], getUltimaVisita);
 
export default router;