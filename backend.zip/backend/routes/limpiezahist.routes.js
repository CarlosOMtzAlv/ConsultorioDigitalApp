// app/routes/LimpiezaHist.routes.js
import express from "express";
import {
    getAllLimpiezaHist,
    getLimpiezaHist,
    insertLimpiezaHist,
    updateLimpiezaHist,
    deleteLimpiezaHist
} from "../controllers/LimpiezaHist.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllLimpiezaHist);
 
router.get("/:id", [verifyToken], getLimpiezaHist);
 
router.post("/", [verifyToken], insertLimpiezaHist);

router.put("/:id", [verifyToken], updateLimpiezaHist);
 
router.delete("/:id", [verifyToken], deleteLimpiezaHist);
 
export default router;