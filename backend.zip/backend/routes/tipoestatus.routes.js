// app/routes/tipoestatus.routes.js
import express from "express";
import {
    getAllTipoEstatus,
    getTipoEstatus,
    insertTipoEstatus,
    updateTipoEstatus,
    deleteTipoEstatus
} from "../controllers/tipoestatus.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllTipoEstatus);
 
router.get("/:id", [verifyToken], getTipoEstatus);
 
router.post("/create", [verifyToken], insertTipoEstatus);

router.post("/update/:id", [verifyToken], updateTipoEstatus);
 
router.post("/delete/:id", [verifyToken], deleteTipoEstatus);
 
export default router;