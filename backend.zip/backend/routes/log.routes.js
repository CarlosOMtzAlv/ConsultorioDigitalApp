// app/routes/Log.routes.js
import express from "express";
import {
    getAllLogs,
    getLog,
    insertLog,
    updateLog,
    deleteLog
} from "../controllers/Log.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllLogs);
 
router.get("/:id", [verifyToken], getLog);
 
router.post("/", [verifyToken], insertLog);

router.put("/:id", [verifyToken], updateLog);
 
router.delete("/:id", [verifyToken], deleteLog);
 
export default router;