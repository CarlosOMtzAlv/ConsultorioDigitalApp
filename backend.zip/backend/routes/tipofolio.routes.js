// app/routes/tipoFolio.routes.js
import express from "express";
import {
    getAllTipoFolio,
    getTipoFolio,
    insertTipoFolio,
    updateTipoFolio,
    deleteTipoFolio
} from "../controllers/tipofolio.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllTipoFolio);
 
router.get("/:id", [verifyToken], getTipoFolio);
 
router.post("/", [verifyToken], insertTipoFolio);

router.put("/:id", [verifyToken], updateTipoFolio);
 
router.delete("/:id", [verifyToken], deleteTipoFolio);
 
export default router;