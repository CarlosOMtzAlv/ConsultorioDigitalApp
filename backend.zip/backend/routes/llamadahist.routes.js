// app/routes/LlamadaHist.routes.js
import express from "express";
import {
    getAllLlamadaHist,
    getLlamadaHist,
    insertLlamadaHist,
    updateLlamadaHist,
    deleteLlamadaHist
} from "../controllers/LlamadaHist.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllLlamadaHist);
 
router.get("/:id", [verifyToken], getLlamadaHist);
 
router.post("/", [verifyToken], insertLlamadaHist);

router.put("/:id", [verifyToken], updateLlamadaHist);
 
router.delete("/:id", [verifyToken], deleteLlamadaHist);
 
export default router;