// app/routes/estado.routes.js
import express from "express";
import {
    getAlldetOdontogramas,
    getdetOdontograma,
    insertdetOdontograma,
    updatedetOdontograma,
    deletedetOdontograma
} from "../controllers/detodontograma.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAlldetOdontogramas);
 
router.get("/:id", [verifyToken], getdetOdontograma);
 
router.post("/", [verifyToken], insertdetOdontograma);

router.put("/:id", [verifyToken], updatedetOdontograma);
 
router.delete("/:id", [verifyToken], deletedetOdontograma);
 
export default router;