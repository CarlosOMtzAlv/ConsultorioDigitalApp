// app/routes/estado.routes.js
import express from "express";
import {
    getAllPresupuestos,
    getPresupuesto,
    createPresupuesto,
    updatePresupuesto,
    deletePresupuesto
} from "../controllers/presupuesto.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllPresupuestos);
 
router.get("/:id", [verifyToken], getPresupuesto);
 
router.post("/", [verifyToken], createPresupuesto);

router.put("/:id", [verifyToken], updatePresupuesto);
 
router.delete("/:id", [verifyToken], deletePresupuesto);
 
export default router;