// app/routes/Precio.routes.js
import express from "express";
import {
    getAllPrecio,
    getPrecio,
    insertPrecio,
    updatePrecio,
    deletePrecio
} from "../controllers/precio.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllPrecio);
 
router.get("/:id", [verifyToken], getPrecio);
 
router.post("/", [verifyToken], insertPrecio);

router.put("/:id", [verifyToken], updatePrecio);
 
router.delete("/:id", [verifyToken], deletePrecio);
 
export default router;