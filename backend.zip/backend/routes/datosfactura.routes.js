// app/routes/datosFactura.routes.js
import express from "express";
import {
    getAllDatosFacturas,
    getDatosFactura,
    insertDatosFactura,
    updateDatosFactura,
    deleteDatosFactura
} from "../controllers/datosfactura.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllDatosFacturas);
 
router.get("/:id", [verifyToken], getDatosFactura);
 
router.post("/", [verifyToken], insertDatosFactura);

router.put("/:id", [verifyToken], updateDatosFactura);
 
router.delete("/:id", [verifyToken], deleteDatosFactura);
 
export default router;