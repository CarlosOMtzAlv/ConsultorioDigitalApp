// app/routes/Orden.routes.js
import express from "express";
import {
    getAllOrden,
    getOrden,
    insertOrden,
    updateOrden,
    deleteOrden
} from "../controllers/Orden.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllOrden);
 
router.get("/:id", [verifyToken], getOrden);
 
router.post("/", [verifyToken], insertOrden);

router.put("/:id", [verifyToken], updateOrden);
 
router.delete("/:id", [verifyToken], deleteOrden);
 
export default router;