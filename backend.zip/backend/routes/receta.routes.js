// app/routes/Recetas.routes.js
import express from "express";
import {
    getAllRecetas,
    getRecetas,
    insertRecetas,
    updateRecetas,
    deleteRecetas
} from "../controllers/receta.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllRecetas);
 
router.get("/:id", [verifyToken], getRecetas);
 
router.post("/", [verifyToken], insertRecetas);

router.put("/:id", [verifyToken], updateRecetas);
 
router.delete("/:id", [verifyToken], deleteRecetas);
 
export default router;