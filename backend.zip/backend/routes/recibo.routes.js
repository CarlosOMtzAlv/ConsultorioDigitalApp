// app/routes/Recibos.routes.js
import express from "express";
import {
    getAllRecibos,
    getRecibos,
    insertRecibos,
    updateRecibos,
    deleteRecibos
} from "../controllers/recibo.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllRecibos);
 
router.get("/:id", [verifyToken], getRecibos);
 
router.post("/", [verifyToken], insertRecibos);

router.put("/:id", [verifyToken], updateRecibos);
 
router.delete("/:id", [verifyToken], deleteRecibos);
 
export default router;