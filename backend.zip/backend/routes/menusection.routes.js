// app/routes/menusection.routes.js
import express from "express";
import {
    getAllMenuSections,
    getMenuSection,
    insertMenuSection,
    updateMenuSection,
    deleteMenuSection
} from "../controllers/menusections.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllMenuSections);
 
router.get("/:id", [verifyToken], getMenuSection);
 
router.post("/create", [verifyToken], insertMenuSection);

router.post("/update/:id", [verifyToken], updateMenuSection);
 
router.post("/delete/:id", [verifyToken], deleteMenuSection);
 
export default router;