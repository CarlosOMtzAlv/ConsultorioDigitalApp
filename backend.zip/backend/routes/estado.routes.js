// app/routes/estado.routes.js
import express from "express";
import {
    getAllEstados,
    getEstado,
    insertEstado,
    updateEstado,
    deleteEstado
} from "../controllers/estado.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllEstados);
 
router.get("/:id", [verifyToken], getEstado);
 
router.post("/create", [verifyToken], insertEstado);

router.post("/update/:id", [verifyToken], updateEstado);
 
router.post("/delete/:id", [verifyToken], deleteEstado);
 
export default router;