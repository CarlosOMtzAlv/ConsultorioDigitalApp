// app/routes/formapago.routes.js
import express from "express";
import {
    getAllFormaPagos,
    getFormaPago,
    insertFormaPago,
    updateFormaPago,
    deleteFormaPago
} from "../controllers/formapago.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllFormaPagos);
 
router.get("/:id", [verifyToken], getFormaPago);
 
router.post("/", [verifyToken], insertFormaPago);

router.put("/:id", [verifyToken], updateFormaPago);
 
router.delete("/:id", [verifyToken], deleteFormaPago);
 
export default router;