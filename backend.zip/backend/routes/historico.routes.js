// app/routes/Historicos.routes.js
import express from "express";
import {
    getAllHistoricos,
    getHistorico,
    insertHistorico,
    updateHistorico,
    deleteHistorico
} from "../controllers/historico.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllHistoricos);
 
router.get("/:id", [verifyToken], getHistorico);
 
router.post("/", [verifyToken], insertHistorico);

router.put("/:id", [verifyToken], updateHistorico);
 
router.delete("/:id", [verifyToken], deleteHistorico);
 
export default router;