// app/routes/acciones.routes.js
import express from "express";
import {
    getAllAcciones,
    getAcciones,
    insertAcciones,
    updateAcciones,
    deleteAcciones
} from "../controllers/acciones.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllAcciones);
 
router.get("/:id", [verifyToken], getAcciones);
 
router.post("/", [verifyToken], insertAcciones);

router.put("/:id", [verifyToken], updateAcciones);
 
router.delete("/:id", [verifyToken], deleteAcciones);
 
export default router;