// app/routes/estado.routes.js
import express from "express";
import {
    getAllEventos,
    getEvento,
    insertEvento,
    updateEvento,
    deleteEvento
} from "../controllers/evento.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllEventos);
 
router.get("/:id", [verifyToken], getEvento);
 
router.post("/", [verifyToken], insertEvento);

router.put("/:id", [verifyToken], updateEvento);
 
router.delete("/:id", [verifyToken], deleteEvento);
 
export default router;