// app/routes/Folios.routes.js
import express from "express";
import {
    getAllFolios,
    getFolio,
    insertFolio,
    updateFolio,
    deleteFolio
} from "../controllers/folio.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllFolios);
 
router.get("/:id", [verifyToken], getFolio);
 
router.post("/", [verifyToken], insertFolio);

router.put("/:id", [verifyToken], updateFolio);
 
router.delete("/:id", [verifyToken], deleteFolio);
 
export default router;