// app/routes/motivos.routes.js
import express from "express";
import {
    getAllmotivos,
    getmotivo,
    insertmotivo,
    updatemotivo,
    deletemotivo
} from "../controllers/motivo.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllmotivos);
 
router.get("/:id", [verifyToken], getmotivo);
 
router.post("/", [verifyToken], insertmotivo);

router.put("/:id", [verifyToken], updatemotivo);
 
router.delete("/:id", [verifyToken], deletemotivo);
 
export default router;