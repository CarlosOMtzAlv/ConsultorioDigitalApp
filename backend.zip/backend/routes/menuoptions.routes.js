// app/routes/menuoptions.routes.js
import express from "express";
import {
    getAllMenuOptions,
    getMenuOption,
    insertMenuOption,
    updateMenuOption,
    deleteMenuOption,
    getMenuOptionsBySection
} from "../controllers/menuoptions.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllMenuOptions);
 
router.get("/:id", [verifyToken], getMenuOption);

router.get("/section/:id", [verifyToken], getMenuOptionsBySection);
 
router.post("/", [verifyToken], insertMenuOption);

router.put("/:id", [verifyToken], updateMenuOption);
 
router.post("/:id", [verifyToken], deleteMenuOption);
 
export default router;