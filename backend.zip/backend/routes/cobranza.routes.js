// app/routes/estado.routes.js
import express from "express";
import {
    getAllCobranzas,
    getCobranza,
    insertCobranza,
    updateCobranza,
    deleteCobranza
} from "../controllers/cobranza.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllCobranzas);
 
router.get("/:id", [verifyToken], getCobranza);
 
router.post("/", [verifyToken], insertCobranza);

router.put("/:id", [verifyToken], updateCobranza);
 
router.delete("/:id", [verifyToken], deleteCobranza);
 
export default router;