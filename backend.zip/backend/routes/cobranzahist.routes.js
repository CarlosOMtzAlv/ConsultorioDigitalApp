// app/routes/estado.routes.js
import express from "express";
import {
    getAllCobranzaHist,
    getCobranzaHist,
    insertCobranzaHist,
    updateCobranzaHist,
    deleteCobranzaHist
} from "../controllers/cobranzahist.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllCobranzaHist);
 
router.get("/:id", [verifyToken], getCobranzaHist);
 
router.post("/", [verifyToken], insertCobranzaHist);

router.put("/:id", [verifyToken], updateCobranzaHist);
 
router.delete("/:id", [verifyToken], deleteCobranzaHist);
 
export default router;