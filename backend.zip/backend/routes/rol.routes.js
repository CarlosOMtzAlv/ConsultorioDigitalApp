// app/routes/rol.routes.js
import express from "express";
import {
    getAllroles,
    getRol,
    insertRol,
    updateRol,
    deleteRol
} from "../controllers/rol.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllroles);
 
router.get("/:id", [verifyToken], getRol);
 
router.post("/create", [verifyToken], insertRol);

router.post("/update/:id", [verifyToken], updateRol);
 
router.post("/delete/:id", [verifyToken], deleteRol);
 
export default router;