// app/routes/municipio.routes.js
import express from "express";
import {
    getAllMunicipio,
    getMunicipioEstado,
    getMunicipio,
} from "../controllers/municipio.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllMunicipio);

router.get("/:id", [verifyToken], getMunicipio);

router.get("/completo", [verifyToken], getMunicipioEstado);

export default router;