// app/routes/menuoptionsrole.routes.js
import express from "express";
import {
    getAllMenuOptionsRole,
    insertMenuOptionRole,
    updateMenuOptionRole,
    deleteMenuOptionRole
} from "../controllers/menuoptionsrole.controller.js";
import {
    verifyToken,
    isAdmin,
    isModerator,
    isModeratorOrAdmin,
} from "../middlewares/authJwt.js";

const router = express.Router();
 
router.get("/all", [verifyToken], getAllMenuOptionsRole);
 
router.post("/", [verifyToken], insertMenuOptionRole);

router.put("/:id", [verifyToken], updateMenuOptionRole);
 
router.post("/:id", [verifyToken], deleteMenuOptionRole);
 
export default router;