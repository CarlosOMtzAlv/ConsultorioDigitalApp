// app/models/logs.model.js
export default (sequelize, Sequelize) => {
    const logs = sequelize.define("logs", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        evento: {
            type: Sequelize.STRING
        },
        descripcion: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "logs"
    });
    return logs;
};