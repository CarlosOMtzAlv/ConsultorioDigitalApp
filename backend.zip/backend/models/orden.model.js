// app/models/ordens.model.js
export default (sequelize, Sequelize) => {
    const orden = sequelize.define("orden", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        numPieza: {
            type: Sequelize.STRING
        }
        ,
        orden: {
            type: Sequelize.INTEGER
        }
    },
    {
        tableName: "orden",
        timestamps: false
    });
    return orden;
};