// app/models/motivo.model.js
export default (sequelize, Sequelize) => {
    const motivo = sequelize.define("motivos_hist", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idExpediente: {
            type: Sequelize.INTEGER,
            references: {
                model: 'expedientes',
                key: 'id'
            }
        },
        motivo: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "motivos_hist"
    });
    return motivo;
};