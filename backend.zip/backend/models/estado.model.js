// app/models/Estados.model.js
export default (sequelize, Sequelize) => {
    const Estados = sequelize.define("estados", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        nombre: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "estados"
    });
    return Estados;
};