// app/models/cobranzahist.model.js
export default (sequelize, Sequelize) => {
    const cobranzaHist = sequelize.define("cobranza_hist", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idHistorico: {
            type: Sequelize.INTEGER,
            references: {
                model: 'historicos',
                key: 'id'
            }
        },

        idCobranza: {
            type: Sequelize.INTEGER,
            references: {
                model: 'cobranzas',
                key: 'id'
            }
        }
    },
    {
        tableName: "cobranza_hist"
    });
    return cobranzaHist;
};