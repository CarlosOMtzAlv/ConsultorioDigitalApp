
export default (sequelize, Sequelize) => {

    const ExpedienteModel = sequelize.define('expedientes', {

        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        nombre: {
            type: Sequelize.STRING
        },

        apellidoPaterno: {
            type: Sequelize.STRING
        },

        apellidoMaterno: {
            type: Sequelize.STRING
        },

        fechaNacimiento: {
            type: Sequelize.DATE
        },

        telefono: {
            type: Sequelize.STRING
        },

        email: {
            type: Sequelize.STRING
        },

        contactoEmergencia: {
            type: Sequelize.STRING
        },

        calle: {
            type: Sequelize.STRING
        },

        numInterior: {
            type: Sequelize.STRING
        },

        numExterior: {
            type: Sequelize.STRING
        },

        colonia: {
            type: Sequelize.STRING
        },

        codigoPostal: {
            type: Sequelize.STRING
        },

        idMunicipio: {
            type: Sequelize.INTEGER
        },

        motivoConsulta: {
            type: Sequelize.STRING
        },

        enfermedades: {
            type: Sequelize.STRING
        },

        alergias: {
            type: Sequelize.STRING
        },

        observaciones: {
            type: Sequelize.STRING
        },

        fotoPerfil: {
            type: Sequelize.STRING
        }

    }, {
        tableName: 'expedientes'
    });

    return ExpedienteModel;
};
