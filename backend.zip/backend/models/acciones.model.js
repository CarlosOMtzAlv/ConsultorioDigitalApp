// app/models/acciones.model.js
export default (sequelize, Sequelize) => {
    const Acciones = sequelize.define("acciones", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        idNota: {
            type: Sequelize.INTEGER,
            allowNull: true,
            references: {
                model: 'notas',
                key: 'id'
            }
        },
        idExpediente: {
            type: Sequelize.INTEGER,
            allowNull: false,
            references: {
                model: 'expedientes',
                key: 'id'
            }
        },
        idEvento: {
            type: Sequelize.INTEGER,
            allowNull: true,
            references: {
                model: 'eventos',
                key: 'id'
            }
        },
        idEstatus: {
            type: Sequelize.INTEGER,
            allowNull: true,
            references: {
                model: 'estatus',
                key: 'id'
            }
        }
    },
    {
        tableName: "acciones"
    });
    return Acciones;
};