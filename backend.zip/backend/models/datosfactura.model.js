// app/models/datosfactura.model.js
export default (sequelize, Sequelize) => {
    const datosFactura = sequelize.define("datosfacturas", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idExpediente: {
            type: Sequelize.INTEGER,
            references: {
                model: 'expedientes',
                key: 'id'
            }
        },
        razonSocial: {
            type: Sequelize.STRING
        },
        rfc: {
            type: Sequelize.STRING
        },
        direccion: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "datosfacturas"
    });
    return datosFactura;
};