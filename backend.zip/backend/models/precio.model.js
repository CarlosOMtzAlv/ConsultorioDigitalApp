// app/models/precios.model.js
export default (sequelize, Sequelize) => {
    const precio = sequelize.define("precios", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        trabajo: {
            type: Sequelize.STRING
        }
        ,
        costoUnitario: {
            type: Sequelize.DECIMAL
        }
    },
    {
        tableName: "precios"
    });
    return precio;
};