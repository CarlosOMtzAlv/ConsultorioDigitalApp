// app/models/menu_sections.model.js
export default (sequelize, Sequelize) => {
    const MenuSections = sequelize.define("menu_sections", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        menuNombre: {
            type: Sequelize.STRING
        },
        titulo: {
            type: Sequelize.STRING
        },
        icono: {
            type: Sequelize.STRING
        },
        orden: {
            type: Sequelize.INTEGER
        }
    },
    {
        tableName: "menu_sections"
    });
    return MenuSections;
};