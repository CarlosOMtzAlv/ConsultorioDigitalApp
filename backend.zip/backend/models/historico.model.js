// app/models/Historico.model.js
export default (sequelize, Sequelize) => {
    const Historico = sequelize.define("historicos", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idObjeto: {
            type: Sequelize.INTEGER,
            references: {
                model: 'objetos',
                key: 'id'
            }
        }
    },
    {
        tableName: "historicos"
    });
    return Historico;
};