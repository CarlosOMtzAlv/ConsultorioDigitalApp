// app/models/cobranza.model.js
export default (sequelize, Sequelize) => {
    const limpiezaHist = sequelize.define("limpieza_hist", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idExpediente: {
            type: Sequelize.INTEGER,
            references: {
                model: 'expedientes',
                key: 'id'
            }
        },

        idEstatus: {
            type: Sequelize.INTEGER,
            references: {
                model: 'estatus',
                key: 'id'
            }
        }
    },
    {
        tableName: "limpieza_hist"
    });
    return limpiezaHist;
};