// app/models/recetas.model.js
export default (sequelize, Sequelize) => {
    const recetas = sequelize.define("recetas", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idExpediente: {
            type: Sequelize.INTEGER,
            references: {
                model: 'expedientes',
                key: 'id'
            }
        },
        fecha: {
            type: Sequelize.DATE
        },
        prescripcion: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "recetas"
    });
    return recetas;
};