// app/models/menu_options.model.js
export default (sequelize, Sequelize) => {
    const MenuOptions = sequelize.define("menu_options", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        idSection: {
            type: Sequelize.INTEGER,
            allowNull: false,
            references: {
                model: "menu_sections",
                key: "id"
            }
        },
        optionNombre: {
            type: Sequelize.STRING
        },
        optionTitulo: {
            type: Sequelize.STRING
        },
        ruta: {
            type: Sequelize.STRING
        },
        icono: {
            type: Sequelize.STRING
        },
        orden: {    
            type: Sequelize.INTEGER
        },
        activo: {
            type: Sequelize.BOOLEAN
        }
    },
    {
        tableName: "menu_options"
    });
    return MenuOptions;
};