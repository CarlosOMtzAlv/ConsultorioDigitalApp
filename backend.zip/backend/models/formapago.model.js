// app/models/formapago.model.js
export default (sequelize, Sequelize) => {
    const FormaPagos = sequelize.define("formapagos", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        descPago: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "formapagos"
    });
    return FormaPagos;
};