export default (sequelize, Sequelize) => {
    const presupuestoModel = sequelize.define('presupuestos', {
    
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        fecha: {
            type: Sequelize.DATE,
        }
        ,
    
        idHistorico: {
            type: Sequelize.INTEGER,
            references: {
                model: 'historicos',
                key: 'id'
            }
        },
    
        idExpediente: {
            type: Sequelize.INTEGER,
            references: {
                model: 'expedientes',
                key: 'id'
            }
        },
    
        idPrecios: {
            type: Sequelize.INTEGER,
            references: {
                model: 'precios',
                key: 'id'
            }
        },
    
        numUnidades: {
            type: Sequelize.INTEGER
        },
    
        descuento: {
            type: Sequelize.DECIMAL
        },
        vigenteHasta: {
            type: Sequelize.DATE,
        }
    
    }, {
        tableName: 'presupuestos'
    });
    
        return presupuestoModel;
    
    }