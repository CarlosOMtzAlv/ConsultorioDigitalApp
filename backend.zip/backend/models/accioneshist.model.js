// app/models/accioneshist.model.js
export default (sequelize, Sequelize) => {
    const AccionesHist = sequelize.define("acciones_hist", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idAcciones: {
            type: Sequelize.INTEGER,
            references: {
                model: 'acciones',
                key: 'id'
            }
        },

        idEstatus: {
            type: Sequelize.INTEGER,
            references: {
                model: 'estatus',
                key: 'id'
            }
        }
    },
    {
        tableName: "acciones_hist"
    });
    return AccionesHist;
};