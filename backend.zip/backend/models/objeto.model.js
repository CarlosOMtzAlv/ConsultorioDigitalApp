// app/models/Objetos.model.js
export default (sequelize, Sequelize) => {
    const Objetos = sequelize.define("objetos", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        descripcion: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "objetos"
    });
    return Objetos;
};