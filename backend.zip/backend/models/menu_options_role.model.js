// app/models/menu_option_role.model.js
export default (sequelize, Sequelize) => {
    const RoleMenuOptions = sequelize.define("role_menu_options", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        idRol: {
            type: Sequelize.INTEGER,
            allowNull: false,
            references: {
                model: "roles",
                key: "id"
            }
        },
        idOption: {
            type: Sequelize.INTEGER,
            allowNull: false,
            references: {
                model: "menu_options",
                key: "id"
            }
        },
        isEnabled: {
            type: Sequelize.BOOLEAN
        }
    },
    {
        tableName: "role_menu_options"
    });
    return RoleMenuOptions;
};