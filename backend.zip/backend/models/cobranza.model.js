// app/models/cobranza.model.js
export default (sequelize, Sequelize) => {
    const cobranza = sequelize.define("cobranzas", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idExpediente: {
            type: Sequelize.INTEGER,
            references: {
                model: 'expedientes',
                key: 'id'
            }
        },

        fecha: {
            type: Sequelize.DATE
        },
        
        concepto: {
            type: Sequelize.STRING
        },
        
        costo: {
            type: Sequelize.DECIMAL
        },
        
        pago: {
            type: Sequelize.DECIMAL
        },
        
        adeudo: {
            type: Sequelize.DECIMAL
        }
    },
    {
        tableName: "cobranzas"
    });
    return cobranza;
};