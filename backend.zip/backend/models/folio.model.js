// app/models/folio.model.js
export default (sequelize, Sequelize) => {
    const Folio = sequelize.define("folios", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idTipoFolio: {
            type: Sequelize.INTEGER,
            references: {
                model: 'tipofolios',
                key: 'id'
            }
        },
        NumFolio: {
            type: Sequelize.INTEGER
        }
    },
    {
        tableName: "folios"
    });
    return Folio;
};