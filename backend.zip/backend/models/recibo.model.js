// app/models/recibos.model.js
export default (sequelize, Sequelize) => {
    const recibos = sequelize.define("recibos", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idCobranza: {
            type: Sequelize.INTEGER,
            references: {
                model: 'cobranzas',
                key: 'id'
            }
        },

        idFormaPago: {
            type: Sequelize.INTEGER,
            references: {
                model: 'formapagos',
                key: 'id'
            }
        },
        chkFactura: {
            type: Sequelize.BOOLEAN
        }
    },
    {
        tableName: "recibos"
    });
    return recibos;
};