// app/models/Estatus.model.js
export default (sequelize, Sequelize) => {
    const Estatus = sequelize.define("estatus", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        descripcion: {
            type: Sequelize.STRING
        },

        idTipoEstatus: {
            type: Sequelize.INTEGER,
            references: {
                model: 'tipoestatus',
                key: 'id'
            }
        }
    },
    {
        tableName: "estatus"
    });
    return Estatus;
};