// app/models/tratamiento.model.js
export default (sequelize, Sequelize) => {
    const tratamiento = sequelize.define("tratamientos", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idHistorico: {
            type: Sequelize.INTEGER,
            references: {
                model: 'historicos',
                key: 'id'
            }
        },

        idExpediente: {
            type: Sequelize.INTEGER,
            references: {
                model: 'expedientes',
                key: 'id'
            }
        },
        numPieza: {
            type: Sequelize.STRING
        },
        descPresenta: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "tratamientos"
    });
    return tratamiento;
};