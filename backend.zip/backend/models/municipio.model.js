// app/models/municipio.model.js
export default (sequelize, Sequelize) => {
    const Municipios = sequelize.define("municipios", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        nombre: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "municipios"
    });
    return Municipios;
};