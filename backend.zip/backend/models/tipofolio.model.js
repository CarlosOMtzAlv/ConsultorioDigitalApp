// app/models/tipoFolio.model.js
export default (sequelize, Sequelize) => {
    const TipoFolio = sequelize.define("tipofolios", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        description: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "tipofolios"
    });
    return TipoFolio;
};