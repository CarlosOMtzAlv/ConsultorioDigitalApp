// app/models/cobranza.model.js
export default (sequelize, Sequelize) => {
    const detOdontogramas = sequelize.define("det_odontogramas", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idHistorico: {
            type: Sequelize.INTEGER,
            references: {
                model: 'historicos',
                key: 'id'
            }
        },

        protesisFijas: {
            type: Sequelize.STRING
        },
        
        protesisRem: {
            type: Sequelize.STRING
        },
        
        oclusion: {
            type: Sequelize.STRING
        },
        
        mordida: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "det_odontogramas"
    });
    return detOdontogramas;
};