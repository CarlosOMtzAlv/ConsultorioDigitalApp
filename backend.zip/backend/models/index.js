// app/models/index.js
import Sequelize from "sequelize";
import dbConfig from "../config/db.config.js";

import accionesModel from "./acciones.model.js";
import accioneshistModel from "./accioneshist.model.js";
import cobranzaModel from "./cobranza.model.js";
import cobranzahistModel from "./cobranzahist.model.js";
import datosfacturaModel from "./datosfactura.model.js";
import detodontogramaModel from "./detodontograma.model.js";
import dettratamientoModel from "./dettratamiento.model.js";
import folioModel from "./folio.model.js";
import formapagoModel from "./formapago.model.js";
import historicoModel from "./historico.model.js";
import estadosModel from "./estado.model.js";
import estatusModel from "./estatus.model.js";
import eventoModel from "./evento.model.js";
import expedienteModel from "./expediente.model.js";
import limpiezahistModel from "./limpiezahist.model.js";
import llamadahistModel from "./llamadahist.model.js";
import logModel from "./log.model.js";
import menu_sectionsModel from "./menu_sections.model.js";
import menu_optionsModel from "./menu_options.model.js";
import menu_optionsRoleModel from "./menu_options_role.model.js";
import motivoModel from "./motivo.model.js";
import municipioModel from "./municipio.model.js";
import notaModel from "./nota.model.js";
import objetoModel from "./objeto.model.js";
import odontogramaModel from "./odontograma.model.js";
import ordenModel from "./orden.model.js";
import precioModel from "./precio.model.js";
import presupuestoModel from "./presupuesto.model.js";
import recetaModel from "./receta.model.js";
import reciboModel from "./recibo.model.js";
import roleModel from "./role.model.js";
import tipoestatusModel from "./tipoestatus.model.js";
import tipofolioModel from "./tipofolio.model.js";
import tratamientoModel from "./tratamiento.model.js";
import userModel from "./user.model.js";
 
const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
    host: dbConfig.HOST,
    dialect: dbConfig.dialect,
    pool: dbConfig.pool,
    port: dbConfig.PORT,
});
 
const db = {};
 
db.Sequelize = Sequelize;
db.sequelize = sequelize;
 
db.acciones = accionesModel(sequelize, Sequelize);
db.accioneshist = accioneshistModel(sequelize, Sequelize);
db.cobranzas = cobranzaModel(sequelize, Sequelize);
db.cobranzahist = cobranzahistModel(sequelize, Sequelize);
db.datosfacturas = datosfacturaModel(sequelize, Sequelize);
db.detodontogramas = detodontogramaModel(sequelize, Sequelize);
db.dettratamientos = dettratamientoModel(sequelize, Sequelize);
db.folios = folioModel(sequelize, Sequelize);
db.formapagos = formapagoModel(sequelize, Sequelize);
db.historicos = historicoModel(sequelize, Sequelize);
db.estados = estadosModel(sequelize, Sequelize);
db.estatus = estatusModel(sequelize, Sequelize);
db.eventos = eventoModel(sequelize, Sequelize);
db.expedientes = expedienteModel(sequelize, Sequelize);
db.limpiezahist = limpiezahistModel(sequelize, Sequelize);
db.llamadahist = llamadahistModel(sequelize, Sequelize);
db.logs = logModel(sequelize, Sequelize);
db.menusections = menu_sectionsModel(sequelize, Sequelize);
db.menuoptions = menu_optionsModel(sequelize, Sequelize);
db.menuoptionsrole = menu_optionsRoleModel(sequelize, Sequelize);
db.motivos = motivoModel(sequelize, Sequelize);
db.municipios = municipioModel(sequelize, Sequelize);
db.notas = notaModel(sequelize, Sequelize);
db.objetos = objetoModel(sequelize, Sequelize);
db.odontogramas = odontogramaModel(sequelize, Sequelize);
db.orden = ordenModel(sequelize, Sequelize);
db.precios = precioModel(sequelize, Sequelize);
db.presupuestos = presupuestoModel(sequelize, Sequelize);
db.recetas = recetaModel(sequelize, Sequelize);
db.recibos = reciboModel(sequelize, Sequelize);
db.role = roleModel(sequelize, Sequelize);
db.tipoestatus = tipoestatusModel(sequelize, Sequelize);
db.tipofolio = tipofolioModel(sequelize, Sequelize);
db.tratamientos = tratamientoModel(sequelize, Sequelize);
db.user = userModel(sequelize, Sequelize);
 
db.role.belongsToMany(db.user, {
    through: "user_roles",
    foreignKey: "roleId",
    otherKey: "userId",
});
db.user.belongsToMany(db.role, {
    through: "user_roles",
    foreignKey: "userId",
    otherKey: "roleId",
    as: "roles",
});

db.estados.belongsToMany(db.municipios, {
  through: "estados_municipios",
  foreignKey: "estados_id",   // 👈 columnas en la tabla pivote
  otherKey: "municipios_id",
  as: "municipios",
});

db.municipios.belongsToMany(db.estados, {
  through: "estados_municipios",
  foreignKey: "estados_id",   // 👈 columnas en la tabla pivote
  otherKey: "municipios_id",
  as: "estados",
});

db.menusections.hasMany(db.menuoptions, {
  foreignKey: "idSection",
  as: "menu_options",
});

db.menuoptions.belongsTo(db.menusections,{
  foreignKey: "idSection",
  as: "menu_sections"
});

db.menuoptionsrole.belongsTo(db.role,{
  foreignKey: "idRol",
  as: "roles"
});

db.menuoptionsrole.belongsTo(db.menuoptions,{
  foreignKey: "idOption",
  as: "menu_options"
});

db.role.hasMany(db.menuoptionsrole, {
  foreignKey: "idRol",
  as: "role_menu_options"
});

db.menuoptions.hasMany(db.menuoptionsrole, {
  foreignKey: "idOption",
  as: "role_menu_options"
});

db.historicos.hasMany(db.objetos, {foreignKey:"id", as: "objetos"});
db.objetos.belongsTo(db.historicos, {foreignKey:"idObjeto", as: "historicos"});
 
db.ROLES = ["user", "admin", "moderator"];
 
export default db;