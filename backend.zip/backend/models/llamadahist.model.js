// app/models/cobranza.model.js
export default (sequelize, Sequelize) => {
    const llamadaHist = sequelize.define("llamada_hist", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idExpediente: {
            type: Sequelize.INTEGER,
            references: {
                model: 'expedientes',
                key: 'id'
            }
        },

        idEstatus: {
            type: Sequelize.INTEGER,
            references: {
                model: 'estatus',
                key: 'id'
            }
        }
    },
    {
        tableName: "llamada_hist"
    });
    return llamadaHist;
};