// app/models/tipoestatus.model.js
export default (sequelize, Sequelize) => {
    const TipoEstatus = sequelize.define("tipoestatus", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        descripcion: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "tipoestatus"
    });
    return TipoEstatus;
};