// app/models/cita.model.js
export default (sequelize, Sequelize) => {
    const Cita = sequelize.define("citas", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        idExpediente: {
            type: Sequelize.INTEGER,
            references: 'expedientes',
            referencesKey: 'id'
        },
        fecha: { type: Sequelize.DATE },
        concepto: {
            type: Sequelize.STRING
        },
        hora: { type: Sequelize.TIME },
        concepto: {
            type: Sequelize.STRING
        },
    });
 
    return Cita;
};

