export default (sequelize, Sequelize) => {
const NotaModel = sequelize.define('notas', {

    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },

    idExpediente: {
        type: Sequelize.INTEGER,
        references: {
            model: 'expedientes',
            key: 'id'
        }
    },

    fecha: {
        type: Sequelize.DATE
    },

    descripcion: {
        type: Sequelize.STRING
    },

    idEvento: {
        type: Sequelize.INTEGER,
        references: {
            model: 'eventos',
            key: 'id'
        }
    },

    descEvento: {
        type: Sequelize.STRING
    },

    chkLimpieza: {
        type: Sequelize.BOOLEAN
    }

}, {
    tableName: 'notas'
});

    return NotaModel;

}