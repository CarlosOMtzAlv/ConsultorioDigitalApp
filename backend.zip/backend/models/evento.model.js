
export default (sequelize, Sequelize) => {

    const EventoModel = sequelize.define('eventos', {

        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        nombre: {
            type: Sequelize.STRING
        }

    }, {
        tableName: 'eventos'
    });

    return EventoModel;
};
