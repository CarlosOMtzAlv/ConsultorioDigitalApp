// app/models/odontograma.model.js
export default (sequelize, Sequelize) => {
    const odontograma = sequelize.define("odontogramas", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },

        idHistorico: {
            type: Sequelize.INTEGER,
            references: {
                model: 'historicos',
                key: 'id'
            }
        },

        idExpediente: {
            type: Sequelize.INTEGER,
            references: {
                model: 'expedientes',
                key: 'id'
            }
        },
        numPieza: {
            type: Sequelize.STRING
        },
        descPresenta: {
            type: Sequelize.STRING
        }
    },
    {
        tableName: "odontogramas"
    });
    return odontograma;
};